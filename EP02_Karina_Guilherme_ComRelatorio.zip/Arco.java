public class Arco {
    public int chave1;
    public int chave2;
    public int peso;
    public Arco irmao;

    Arco(int chave1, int chave2, int peso) {
        this.chave1 = chave1;
        this.chave2 = chave2;
        this.peso = peso;
    }
}
