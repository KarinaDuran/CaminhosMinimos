public class Vertice {
    public int chave;
    public Arco primeiroArco;

    public Vertice(int nome) {
        this.chave = nome;
        this.primeiroArco = null;
    }
}
